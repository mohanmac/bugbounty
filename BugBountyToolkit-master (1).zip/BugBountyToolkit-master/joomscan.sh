#!/bin/bash

perl ~/toolkit/joomscan/joomscan.pl "$@"
